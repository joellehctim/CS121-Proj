package bigOActivity;

public class Test {
    public static void main(String[] args) {


        bigO a = new bigO();
        a.printOnce(4);
        a.printNTimes(7);
        a.printNSquaredTimes(3);
    }
}
