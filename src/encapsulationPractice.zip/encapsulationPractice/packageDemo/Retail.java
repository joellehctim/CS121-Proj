package encapsulationPractice.packageDemo;

import javax.imageio.plugins.tiff.GeoTIFFTagSet;

public class Retail {


    String manager, location;
    private int sales, expenses, staff, margin;




    public Retail(String manager, String location, int sales, int expenses){
        this.manager = manager;
        this.location = location;
        this.sales= sales;
        this.expenses = expenses;

    }

    public void setStaff(int staff){this.staff= staff;}

    public int getStaff() {
        return staff;
    }
    public void setSales(int sales){this.sales= sales;}

        public int getSales(){
            return sales;
    }
    public void setMargin(int margin){this.margin= sales-expenses;}

    public int getMargin(){
        return margin;}
    public void setExpenses(int expenses){this.expenses= expenses;}

    public int getExpenses(){
        return expenses;}

    private void getStoreInfo(){
        System.out.printf("\nStore: %s \nManager: $s \nStaff Members: %d\nMargin: %d$", location, manager, staff, margin);
    }
    void getManager(){
        System.out.printf("\nManager: %s", manager);
    }
    protected void getProfit(){
        System.out.printf("Profit: %d $", margin);
    }
}


