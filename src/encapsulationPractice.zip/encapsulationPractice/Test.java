package encapsulationPractice;

import encapsulationPractice.packageDemo.Retail;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Retail Marshalls = new Retail("Kerry", "Indy", 15000, 10000);
        System.out.println("How many staff members does this location have?");
        Marshalls.setStaff(Integer.parseInt(scanner.nextLine()));
        //Marshalls.getStoreInfo();
       // Marshalls.getProfit();
        //Marshalls.getManager();



    }
}
