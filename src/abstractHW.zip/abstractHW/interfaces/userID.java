package abstractHW.interfaces;

public interface userID {
    String createuserID();
}
