package classActivity;

public class Htest {
    public static void main(String[] args) {
        House house = new House();
        Apartment apartment = new Apartment();
        apartment.displayinfo();
        house.displayinfo();

    }


}
