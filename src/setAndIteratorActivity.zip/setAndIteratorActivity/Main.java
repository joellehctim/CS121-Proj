package setAndIteratorActivity;

public class Main {
    public static void main(String[] args) {
        MovieCollectionSet movies = new MovieCollectionSet();
        movies.addMovies();

        movies.displayMovies();
    }
}
